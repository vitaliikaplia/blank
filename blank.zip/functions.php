<?php

if(!defined('ABSPATH')){exit;}

/** let's go! */
require_once 'core' . DIRECTORY_SEPARATOR . 'init.php';
