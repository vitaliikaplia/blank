/**
 * variables
 */
// const ajaxUrl = "/wp-admin/admin-ajax.php";
// const siteCookieDomain = "."+document.location.hostname.replace("www.","");
