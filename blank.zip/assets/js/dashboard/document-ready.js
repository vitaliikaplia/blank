/**
 * document ready
 */
// (function ($) {
//     $(document).ready(function () {
//
//     });
// })(jQuery);
