/**
 * window load resize
 */
// (function ($) {
//     $(window).on("load resize", function () {
//
//     });
// })(jQuery);
