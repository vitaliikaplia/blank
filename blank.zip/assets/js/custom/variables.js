/**
 * variables
 */
const isMobile = navigator.userAgent.match(/Mobile/i) == "Mobile";
const ajaxUrl = "/wp-admin/admin-ajax.php";
const siteCookieDomain = "."+document.location.hostname.replace("www.","");
