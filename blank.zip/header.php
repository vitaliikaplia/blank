<?php

if(!defined('ABSPATH')){exit;}

$GLOBALS['timberContext'] = Timber::context();
ob_start();
