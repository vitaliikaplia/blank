/**
 * window load scroll resize
 */
// (function ($) {
//     $(window).on("load scroll resize", function () {
//
//     });
// })(jQuery);
