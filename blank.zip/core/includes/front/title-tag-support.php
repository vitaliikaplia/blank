<?php

if(!defined('ABSPATH')){exit;}

/** let WordPress manage the document title */
add_theme_support( 'title-tag' );
